/*
 * The original version of this came from here: https://github.com/vdavid/facebook-messenger-json-viewer
 * But this is a completely revamped app.
 */

import App from './components/App.mjs';

ReactDOM.render(React.createElement(App), document.getElementById('app'));